<?php 
//database.php
$connect = mysqli_connect("localhost", "root", "password", "uichu");

?>

