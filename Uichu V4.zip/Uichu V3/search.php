<?php
    require('database.php'); 

    $sql = "SELECT * FROM producto WHERE LOWER(nombre) LIKE LOWER('%".$_POST['nombre']."%')";
    $result = mysqli_query($connect, $sql);
    if($result->num_rows>0) {
        while($fila=$result->fetch_assoc()) {
            echo '<div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
            <div class="products-single fix">
                <div class="box-img-hover">
                    <img src="img/products/'.$fila['imagen'].'" style="width: 200px; height: 250px;" class="img-fluid" alt="Image">
                    <div class="mask-icon">
                        <ul>
                            <li><a href="#" data-toggle="tooltip" data-placement="right" title="View"><i class="fas fa-eye"></i></a></li>
                            <li><a href="#" data-toggle="tooltip" data-placement="right" title="Compare"><i class="fas fa-sync-alt"></i></a></li>
                            <li><a href="#" data-toggle="tooltip" data-placement="right" title="Add to Wishlist"><i class="far fa-heart"></i></a></li>
                        </ul>
                        <a class="cart" href="#">Añadir al carrito</a>
                    </div>
                </div>
                <div class="why-text">
                    <h3>'.$fila['nombre'].'</h4>
                    <h4>'.$fila['categoria'].'</h4>
                    <h5>$'.$fila['precio'].'</h5>
                </div>
            </div>
        </div>';
        }
    }
    else {
        echo "<h3>No se encontraron los productos!</h3>";
    }

?>
